﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymAdministration.Core
{
    public enum StatusEnum
    {
        Inactive = 0,
        Active = 1
    }
}
