﻿

using GymAdministration.Core;

List<Employee> employees = new List<Employee>();
employees.Add(new Employee("Gym"));
employees.Add(new Employee("Gym2"));
employees.Add(new Employee("Gym3"));
employees.Add(new Employee("Gym4"));
employees.Add(new Employee("Gym5"));

foreach (Employee employee in employees)
{
    Console.WriteLine($"Academias: {employee.Name}, Status: {employee.Status}");
}

Console.ReadKey(); 